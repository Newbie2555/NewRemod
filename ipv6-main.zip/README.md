### Command Install

```
rm -f setup.sh && apt update && apt upgrade -y && wget autosc.me/s/setup.sh && bash setup.sh
```


------------
**Telegram**
------------
[FSIDVPN](https://t.me/FER1DEV)

### Fitur Script
• SSH & OpenVPN

• XRAY VMESS 

• XRAY VLESS

• XRAY TROJAN

• TROJAN GO

### Os Supported

• Support Debian 10 (Only)
# Service & Port

• OpenSSH                 : 8443, 22

• OpenVPN                 : [ ERROR ]

• Stunnel5                : 8443, 445, 777

• Dropbear                : 8443, 109, 143

• Squid Proxy             : 3128, 8080

• Badvpn                  : 7100, 7200, 7300

• Nginx                   : 89

• XRAYS Vmess TLS         : 443

• XRAYS Vmess None TLS    : 80

• XRAYS Vless TLS         : 443

• XRAYS Vless None TLS    : 80

• XRAYS Trojan            : 2083

• Websocket TLS           : [OFF/ERROR]

• Websocket None TLS      : [OFF/ERROR]

• Websocket Ovpn          : [OFF/ERROR]

• Trojan Go               : 2087

 ### Server Information & Other Features

• Timezone                : Asia/Jakarta (GMT +7)

• Fail2Ban                : [ON]

• Dflate                  : [ON]

• IPtables                : [OFF]

• Auto-Reboot             : [OFF]

• IPv6                    : [ONN]

• Full Orders For Various Services

• White Label




------------
**Telegram**
------------
[FSIDVPN](https://t.me/FER1DEV)
